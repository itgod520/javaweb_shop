package com.domain;

public class User {
	private String ordinaryUser;
	private String password;
	private String sex;
	private String register_date;
	public String getOrdinaryUser() {
		return ordinaryUser;
	}
	public void setOrdinaryUser(String ordinaryUser) {
		this.ordinaryUser = ordinaryUser;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getRegister_date() {
		return register_date;
	}
	public void setRegister_date(String register_date) {
		this.register_date = register_date;
	}
	

}
