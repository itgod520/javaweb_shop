package com.domain;

public class Product_info {
	private String produce_name;//��Ʒ��
	private String product_id;//��Ʒid
	private String shop_id;//�̵�id
	private double price;//��Ʒ�۸�
	private String pay_method;
	private String order_id;
	private String produce_lei;
	private String status;
	public String getStatus() {
		
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getProduce_lei() {
		return produce_lei;
	}
	public void setProduce_lei(String produce_lei) {
		this.produce_lei = produce_lei;
	}
	public String getOrder_id() {
		return order_id;
	}
	public void setOrder_id(String order_id) {
		this.order_id = order_id;
	}
	public String getPay_method() {
		return pay_method;
	}
	public void setPay_method(String pay_method) {
		this.pay_method = pay_method;
	}
	private int count;//
	private String ordianryUser;
	public String getOrdianryUser() {
		return ordianryUser;
	}
	public void setOrdianryUser(String ordianryUser) {
		this.ordianryUser = ordianryUser;
	}
	private String product_business;//�̼���
	private String order_num;//������
	public String getProduct_business() {
		return product_business;
	}
	public String getProduce_name() {
		return produce_name;
	}
	public void setProduce_name(String produce_name) {
		this.produce_name = produce_name;
	}
	public void setProduct_business(String product_business) {
		this.product_business = product_business;
	}
	public String getOrder_num() {
		return order_num;
	}
	public void setOrder_num(String order_num) {
		this.order_num = order_num;
	}
	public String getOrder_date() {
		return order_date;
	}
	public void setOrder_date(String order_date) {
		this.order_date = order_date;
	}
	private String order_date;//��������
	public double getPrice() {
		return price;
	}
	public void setPrice(double d) {
		this.price = d;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
	public String getShop_id() {
		return shop_id;
	}
	public void setShop_id(String shop_id) {
		this.shop_id = shop_id;
	}
	
	public String getProduct_id() {
		return product_id;
	}
	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}
	
	
	
}
