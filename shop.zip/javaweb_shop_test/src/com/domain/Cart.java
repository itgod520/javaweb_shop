package com.domain;

import java.util.HashMap;
import java.util.Map;

public class Cart {
	private Map<String,CartItem> itemMap=new HashMap<String,CartItem>();
	private double total=0.0;
	public Map<String, CartItem> getItemMap() {
		return itemMap;
	}
	public void setItemMap(Map<String, CartItem> itemMap) {
		this.itemMap = itemMap;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	
	//
	public void add2cart(CartItem item){
		String product_id=item.getProduct().getProduct_id();
		if(itemMap.containsKey(product_id)){
			CartItem oItem=itemMap.get(product_id);
			oItem.setCount(oItem.getCount()+item.getCount());
		}
		else{
			itemMap.put(product_id,item);
			
		}
		total+=item.getSubtotal();
	}
	
     public void removeFromCart(String product_id){
	   CartItem item =itemMap.remove(product_id);
	   total-=item.getSubtotal();
	}

      public void clearCart(){
	      itemMap.clear();
	      total=0.0;
     }
}
