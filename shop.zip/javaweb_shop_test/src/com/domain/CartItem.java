package com.domain;
/**
 * ������
 * */
public class CartItem {
	private Product_info product;
	private double subtotal;
	private Integer count;

	public Product_info getProduct() {
		return product;
	}

	public void setProduct(Product_info product) {
		this.product = product;
	}

	public double getSubtotal() {
		return product.getPrice() * count;
	}

	// public void setSubtotal(double subtotal) {
	// this.subtotal = subtotal;
	// }
	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	public CartItem(Product_info product,Integer count ) {
		super();
		// TODO Auto-generated constructor stub
		this.count=count;
		this.product=product;
	}

	

}
