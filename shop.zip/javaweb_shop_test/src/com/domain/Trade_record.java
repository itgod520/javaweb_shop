package com.domain;

public class Trade_record {
	private String trade_id;
	private String trade_time;
	private String trade_price;
	private String ordinaryUser;
	private String pay_method;
	public String getPay_method() {
		return pay_method;
	}
	public void setPay_method(String pay_method) {
		this.pay_method = pay_method;
	}
	public String getTrade_id() {
		return trade_id;
	}
	public void setTrade_id(String trade_id) {
		this.trade_id = trade_id;
	}
	public String getTrade_time() {
		return trade_time;
	}
	public void setTrade_time(String trade_time) {
		this.trade_time = trade_time;
	}
	public String getTrade_price() {
		return trade_price;
	}
	public void setTrade_price(String trade_price) {
		this.trade_price = trade_price;
	}
	public String getOrdinaryUser() {
		return ordinaryUser;
	}
	public void setOrdinaryUser(String ordinaryUser) {
		this.ordinaryUser = ordinaryUser;
	}
	
	
}
