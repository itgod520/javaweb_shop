package com.domain;

/**
 * @author 14092
 *
 */
public class Business {
	private String businessUser;
	private String password;
	private String register_date;
	private String sex;
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getBusinessUser() {
		return businessUser;
	}
	public void setBusinessUser(String businessUser) {
		this.businessUser = businessUser;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRegister_date() {
		return register_date;
	}
	public void setRegister_date(String register_date) {
		this.register_date = register_date;
	}
	
}
