package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.db.DbConnect;
import com.domain.Product_info;
import com.domain.Trade_record;

public class UserDao_trade_record {
	public int getPageCount(int pageSize) throws Exception{
		
		 Connection conn = null;
		 PreparedStatement ps = null;
		 ResultSet rs = null;
		int recordCount=0,t1=0,t2=0;
		try {
				conn = DbConnect.getDBconnection();
				String sql = "select count(*) from shop_produce";
				ps=conn.prepareStatement(sql);
				rs=ps.executeQuery();
				 rs.next();
				 recordCount=rs.getInt(1);
				 t1=recordCount%pageSize;
				 t2=recordCount/pageSize;
				
			}finally {
				DbConnect.closeDB(conn, ps, rs);
			}
			 return t1==0?t2:t2+1;
	}
	
	public int getPageCount2(int pageSize) throws Exception{
		
		 Connection conn = null;
		 PreparedStatement ps = null;
		 ResultSet rs = null;
		int recordCount=0,t1=0,t2=0;
		try {
				conn = DbConnect.getDBconnection();
				String sql = "select count(*) from shop_produce where status=?";
				ps=conn.prepareStatement(sql);
				ps.setString(1,"��");
				rs=ps.executeQuery();
				 rs.next();
				 recordCount=rs.getInt(1);
				 t1=recordCount%pageSize;
				 t2=recordCount/pageSize;
				
			}finally {
				DbConnect.closeDB(conn, ps, rs);
			}
			 return t1==0?t2:t2+1;
	}
	
	public int getPageCount3(int pageSize) throws Exception{
		
		 Connection conn = null;
		 PreparedStatement ps = null;
		 ResultSet rs = null;
		int recordCount=0,t1=0,t2=0;
		try {
				conn = DbConnect.getDBconnection();
				String sql = "select count(*) from delect_order_record ";
				ps=conn.prepareStatement(sql);
				
				rs=ps.executeQuery();
				 rs.next();
				 recordCount=rs.getInt(1);
				 t1=recordCount%pageSize;
				 t2=recordCount/pageSize;
				
			}finally {
				DbConnect.closeDB(conn, ps, rs);
			}
			 return t1==0?t2:t2+1;
	}
	
	public ArrayList<Product_info> findAllUser(int pageNo,int pageSize) throws Exception{
		
		
		 Connection conn = null;
		 PreparedStatement ps = null;
		 ResultSet rs = null;
		 int startRecno=(pageNo-1)*pageSize;
		 ArrayList<Product_info> userList=new ArrayList<Product_info>();
		try {
				conn = DbConnect.getDBconnection();
				String sql = "select * from shop_produce order by produce_id limit ?,?";
				ps=conn.prepareStatement(sql);
				 ps.setInt(1,startRecno);
				 ps.setInt(2,pageSize);
				rs=ps.executeQuery();
				 while(rs.next()){
					 
					 Product_info pro_info=new Product_info();
					 pro_info.setProduct_id(rs.getString(1));
					 pro_info.setShop_id(rs.getString(2));
					 pro_info.setProduce_name(rs.getString(3));
					 pro_info.setPrice(rs.getDouble(4));
					 pro_info.setOrdianryUser(rs.getString(5));
					 pro_info.setPay_method(rs.getString(6));
					 pro_info.setOrder_id(rs.getString(7));
					 pro_info.setStatus(rs.getString(8));
					 userList.add(pro_info);
				 }
				
			}finally {
				DbConnect.closeDB(conn, ps, rs);;
			}
			 return userList;
	}
	
	
	public ArrayList<Product_info> findAllUser2(int pageNo,int pageSize) throws Exception{
		
		
		 Connection conn = null;
		 PreparedStatement ps = null;
		 ResultSet rs = null;
		 int startRecno=(pageNo-1)*pageSize;
		 ArrayList<Product_info> userList=new ArrayList<Product_info>();
		try {
				conn = DbConnect.getDBconnection();
				String sql = "select * from shop_produce where status=? order by produce_id limit ?,?";
				ps=conn.prepareStatement(sql);
				 ps.setString(1,"��");
				 ps.setInt(2,startRecno);
				 ps.setInt(3,pageSize);
				rs=ps.executeQuery();
				 while(rs.next()){
					 
					 Product_info pro_info=new Product_info();
					 pro_info.setProduct_id(rs.getString(1));
					 pro_info.setShop_id(rs.getString(2));
					 pro_info.setProduce_name(rs.getString(3));
					 pro_info.setPrice(rs.getDouble(4));
					 pro_info.setOrdianryUser(rs.getString(5));
					 pro_info.setPay_method(rs.getString(6));
					 pro_info.setOrder_id(rs.getString(7));
					 pro_info.setStatus(rs.getString(8));
					 userList.add(pro_info);
				 }
				
			}finally {
				DbConnect.closeDB(conn, ps, rs);;
			}
			 return userList;
	}
	
	public ArrayList<Product_info> findAllUser_delect_order_record(int pageNo,int pageSize) throws Exception{
		
		
		 Connection conn = null;
		 PreparedStatement ps = null;
		 ResultSet rs = null;
		 int startRecno=(pageNo-1)*pageSize;
		 ArrayList<Product_info> userList=new ArrayList<Product_info>();
		try {
				conn = DbConnect.getDBconnection();
				String sql = "select * from delect_order_record order by order_id limit ?,?";
				ps=conn.prepareStatement(sql);
				 ps.setInt(1,startRecno);
				 ps.setInt(2,pageSize);
				rs=ps.executeQuery();
				 while(rs.next()){
					 
					 Product_info pro_info=new Product_info();
					 pro_info.setProduct_id(rs.getString(1));
					 pro_info.setShop_id(rs.getString(2));
					 pro_info.setProduce_name(rs.getString(3));
					 pro_info.setPrice(rs.getDouble(4));
					 pro_info.setOrdianryUser(rs.getString(5));
					 pro_info.setPay_method(rs.getString(6));
					 pro_info.setOrder_id(rs.getString(7));
					 pro_info.setStatus(rs.getString(8));
					 userList.add(pro_info);
				 }
				
			}finally {
				DbConnect.closeDB(conn, ps, rs);;
			}
			 return userList;
	}


}
