package com.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.db.DbConnect;
import com.domain.Business;
import com.domain.Product_info;

public class UserDao {

  public int getPageCount_oder(int pageSize ,String userid) throws Exception{
	
	 Connection conn = null;
	 PreparedStatement ps = null;
	 ResultSet rs = null;
	int recordCount=0,t1=0,t2=0;
	try {
			conn = DbConnect.getDBconnection();
			String sql = "select count(*) from shop_produce where ordianryUser=?";
			ps=conn.prepareStatement(sql);
			ps.setString(1,userid);
			rs=ps.executeQuery();
			 rs.next();
			 recordCount=rs.getInt(1);
			 System.out.println(recordCount);
			 t1=recordCount%pageSize;
			 t2=recordCount/pageSize;
			
		}finally {
			DbConnect.closeDB(conn, ps, rs);
		}
		 return t1==0?t2:t2+1;
}
  
  public int getPageCount(int pageSize) throws Exception{
		
		 Connection conn = null;
		 PreparedStatement ps = null;
		 ResultSet rs = null;
		int recordCount=0,t1=0,t2=0;
		try {
				conn = DbConnect.getDBconnection();
				String sql = "select count(*) from businessuser";
				ps=conn.prepareStatement(sql);
				rs=ps.executeQuery();
				 rs.next();
				 recordCount=rs.getInt(1);
				 t1=recordCount%pageSize;
				 t2=recordCount/pageSize;
				
			}finally {
				DbConnect.closeDB(conn, ps, rs);
			}
			 return t1==0?t2:t2+1;
	}
public ArrayList<Business> findAllUser(int pageNo,int pageSize) throws Exception{
	
	
	 Connection conn = null;
	 PreparedStatement ps = null;
	 ResultSet rs = null;
	 int startRecno=(pageNo-1)*pageSize;
	 ArrayList<Business> userList=new ArrayList<Business>();
	try {
			conn = DbConnect.getDBconnection();
			String sql = "select * from businessuser  order by businessUser limit ?,?";
			ps=conn.prepareStatement(sql);
			 ps.setInt(1,startRecno);
			 ps.setInt(2,pageSize);
			rs=ps.executeQuery();
			 while(rs.next()){
				 Business business=new Business();
				 business.setBusinessUser(rs.getString(1));;
				 business.setPassword(rs.getString(2));
				 business.setRegister_date(rs.getString(3));
				 business.setSex(rs.getString(4));
				 userList.add(business);
			 }
			
		}finally {
			DbConnect.closeDB(conn, ps, rs);;
		}
		 return userList;
}

public ArrayList<Product_info> findAllOrder(int pageNo,int pageSize,String userid) throws Exception{
	
	
	 Connection conn = null;
	 PreparedStatement ps = null;
	 ResultSet rs = null;
	 int startRecno=(pageNo-1)*pageSize;
	 ArrayList<Product_info> userList=new ArrayList<Product_info>();
	try {
			conn = DbConnect.getDBconnection();
			String sql = "select * from shop_produce  order by ordianryUser=? limit ?,?";
			ps=conn.prepareStatement(sql);
			 ps.setString(1, userid);
			 ps.setInt(2,startRecno);
			 ps.setInt(3,pageSize);
			rs=ps.executeQuery();
			 while(rs.next()){
				 Product_info business=new Product_info();
				 business.setProduct_id(rs.getString(1));
				 business.setShop_id(rs.getString(2));
				 business.setProduce_name(rs.getString(3));
				 business.setPrice(rs.getDouble(4));
				 business.setOrdianryUser(rs.getString(5));
				 business.setPay_method(rs.getString(6));
				 business.setOrder_id(rs.getString(7));
				 business.setStatus(rs.getString(8));
				 userList.add(business);
			 }
			
		}finally {
			DbConnect.closeDB(conn, ps, rs);;
		}
		 return userList;
}

public static void main(String[] args) {
	UserDao ud=new UserDao();
	try {
		ud.findAllOrder(3, 5, "111");
		
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

}
