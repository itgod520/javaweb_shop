package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.db.DbConnect;
import com.domain.Business;
import com.domain.Product_info;
import com.domain.Student;
import com.domain.Trade_record;

public class Trade_dao implements TradeDAO {
	//protected static final String  FIELDS_INSERT ="businessUser,password,register_date,sex";
		protected static String INSERT_SQL="insert into businessuser (businessUser,password,register_date,sex)"+"values (?,?,?,?)";
		protected static String SELECT_SQL="select * from  businessuser where businessUser=?";
		protected static String UPDATE_SQL="update shop_produce set password=? where businessUser=?";
		protected static String DELETE_SQL ="delete from shop_produce where order_id=?";
		public Trade_record create(Trade_record tr) throws Exception{
			  Connection con=null;
		      PreparedStatement prepStmt=null;
		      ResultSet rs=null;		
		      try{
		    	  con=DbConnect.getDBconnection();  
		    	  prepStmt =con.prepareStatement(INSERT_SQL);	    	  
		    	  prepStmt.setString(1,tr.getTrade_id());
		    	  prepStmt.setString(2,tr.getTrade_time());
		    	  prepStmt.setString(3,tr.getTrade_price());
		    	  prepStmt.setString(4,tr.getOrdinaryUser());
		    	  prepStmt.setString(5,tr.getPay_method());
		          prepStmt.executeUpdate();

		      } finally{
		    	  DbConnect.closeDB(con, prepStmt, rs);
		      }
		     return tr;		
		}
		
		
		public Product_info create_delect_order_record(Product_info pro) throws Exception{
			  Connection con=null;
		      PreparedStatement prepStmt=null;
		      ResultSet rs=null;		
		      try{
		    	  con=DbConnect.getDBconnection();  
		    	  
		    	  prepStmt =con.prepareStatement("insert into delect_order_record(produce_id,shop_id,produce_name,price,ordianryUser,pay_method,order_id,status) select produce_id,shop_id,produce_name,price,ordianryUser,pay_method,order_id,status from shop_produce where order_id=?");	    	  
		    	  prepStmt.setString(1,pro.getOrder_id());
		    	  prepStmt.executeUpdate();

		      } finally{
		    	  DbConnect.closeDB(con, prepStmt, rs);
		      }
		     return pro;		
		}
		
		
		
		public int find(String businessUser,String password) throws Exception {
			Connection con=null;
			int result=0;
		    PreparedStatement prepStmt=null;
		    ResultSet rs=null;
		    Student stu2 =new Student();
		    try {
		    	 con=DbConnect.getDBconnection();
		    	 prepStmt = con.prepareStatement(SELECT_SQL);
	            prepStmt.setString(1,businessUser);
	            rs = prepStmt.executeQuery();
	            if (rs.next()){
	               String a=rs.getString(1);                  
	               String b=rs.getString(2);
	               if(a.equals(businessUser)&&b.equals(password)){
	            	   result=1;
	               }
	               else{
	            	   result=-1;
	               }
	           }
	      } catch (Exception e) {
	          // handle exception
	      } 
	      finally {
	    	  DbConnect.closeDB(con, prepStmt, rs);
	       }
			return result;
		}
		public List<Trade_record> findAll() throws Exception {
			Connection con=null;
		    PreparedStatement prepStmt=null;
		    ResultSet rs=null;	
		    List<Trade_record> business = new ArrayList<Trade_record>();
		    con=DbConnect.getDBconnection();
		    prepStmt = con.prepareStatement("select * from trade_record");
	        rs = prepStmt.executeQuery();
	        while(rs.next()) {
	        	Trade_record stu2 = new Trade_record();
	            stu2.setTrade_id(rs.getString(1));
	            stu2.setTrade_time(rs.getString(2));
	            stu2.setTrade_price(rs.getString(3));
	            stu2.setOrdinaryUser(rs.getString(4));
	            stu2.setPay_method(rs.getString(5));
	            business.add(stu2);
	        }
	        DbConnect.closeDB(con, prepStmt, rs);        
	        return business;
		}
		public int remove(Product_info stu) throws Exception {
			Connection con=null;
			int flag=1;
		    PreparedStatement prepStmt=null;
		    ResultSet rs=null;
		    try {
		    	con=DbConnect.getDBconnection();
		    	prepStmt = con.prepareStatement(DELETE_SQL);
		        prepStmt.setString(1,stu.getOrder_id());
		         flag=prepStmt.executeUpdate();
		        
		    }catch(Exception e) {
		          //
		    } finally{
		    	 DbConnect.closeDB(con, prepStmt, rs);
		    }
		    return flag;
		}
		
		public void update(Student stu) throws Exception {
			Connection con=null;
		    PreparedStatement prepStmt=null;
		    ResultSet rs=null;
		    try {
		    	con=DbConnect.getDBconnection();
	            prepStmt = con.prepareStatement(UPDATE_SQL);
	            prepStmt.setString(1,stu.getPassword());
		    	prepStmt.setString(2,stu.getOrdinaryUser());
		    	
		    	int rowCount=prepStmt.executeUpdate();
	            if (rowCount == 0) {
	                   throw new Exception("Update Error:Student Id:" + stu.getOrdinaryUser());
	            }
	        } catch (Exception e) {
	                // handle exception
	        } finally {
	        	 DbConnect.closeDB(con, prepStmt, rs);
	        }
	    }
		public List<Business> findpart(String user,String pwd ) throws Exception {
			Connection con=null;
		    PreparedStatement prepStmt=null;
		    ResultSet rs=null;	
		    List<Business> student = new ArrayList<Business>();
		    con=DbConnect.getDBconnection();
		    prepStmt = con.prepareStatement("select * from businessUser where businessUser=?");
		    prepStmt.setString(1,user);
	        rs = prepStmt.executeQuery();
//	        for(int i=0;i<10;i++){
//	        	System.out.println(rs.getRow());
//	        }
	        
	       
	        while(rs.next()) {
	        	Business stu2 = new Business();
	            stu2.setBusinessUser(rs.getString(1));                   
	            stu2.setPassword(rs.getString(2));
	            student.add(stu2);
	        }
	        if(rs.getRow()==0){
	        	Business s=new Business();
	        	s.setBusinessUser("*&^%$#@!");
	        	s.setPassword("!@#$%^&*");
	        	student.add(s);
	        	System.out.println("�ҿ����ж���");
	        }
	        DbConnect.closeDB(con, prepStmt, rs);        
	        return student;
		}
		
		
		
		
		public int remove(Business stu) throws Exception {
			Connection con=null;
			int flag=1;
		    PreparedStatement prepStmt=null;
		    ResultSet rs=null;
		    try {
		    	con=DbConnect.getDBconnection();
		    	prepStmt = con.prepareStatement(DELETE_SQL);
		        prepStmt.setString(1,stu.getBusinessUser());
		         flag=prepStmt.executeUpdate();
		        
		    }catch(Exception e) {
		          //
		    } finally{
		    	 DbConnect.closeDB(con, prepStmt, rs);
		    }
		    return flag;
		}
		
		public void update(Business stu) throws Exception {
			Connection con=null;
		    PreparedStatement prepStmt=null;
		    ResultSet rs=null;
		    try {
		    	con=DbConnect.getDBconnection();
	            prepStmt = con.prepareStatement(UPDATE_SQL);
	            prepStmt.setString(1,stu.getPassword());
		    	prepStmt.setString(2,stu.getBusinessUser());
		    	
		    	int rowCount=prepStmt.executeUpdate();
	            if (rowCount == 0) {
	                   throw new Exception("Update Error:Student Id:" + stu.getBusinessUser());
	            }
	        } catch (Exception e) {
	                // handle exception
	        } finally {
	        	 DbConnect.closeDB(con, prepStmt, rs);
	        }
			
		}



		
		public int remove(Trade_record stu) throws Exception {
			// TODO Auto-generated method stub
			return 0;
		}



		
		public void updateStatus(Product_info pro) throws Exception {
			Connection con=null;
		    PreparedStatement prepStmt = null;
		    ResultSet rs=null;
		    try {
		    	con=DbConnect.getDBconnection();
	            prepStmt = con.prepareStatement("update shop_produce set status=? where order_id=?"); 
	            prepStmt.setString(1,pro.getStatus());
	            prepStmt.setString(2,pro.getOrder_id());
		    	
		    	
		    	int rowCount=prepStmt.executeUpdate();
	            if (rowCount == 0) {
	                   throw new Exception("Update Error:Student Id:" + pro.getProduct_id());
	            }
	        } catch (Exception e) {
	                // handle exception
	        } finally {
	        	 DbConnect.closeDB(con, prepStmt, rs);
	        }
		}



		
		public void update(Trade_record stu) throws Exception {
			// TODO Auto-generated method stub
			
		}
		public static void main(String[] args) {
			Trade_dao tdao=new Trade_dao();
			Product_info pro=new Product_info();
			pro.setOrder_id("a18");
			pro.setStatus("shi");
			try {
				tdao.updateStatus(pro);
				System.out.println("���³ɹ�");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
}
