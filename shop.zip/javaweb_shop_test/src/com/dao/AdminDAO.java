package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.db.DbConnect;
import com.domain.Admin;
import com.domain.Business;
import com.domain.Student;

public class AdminDAO implements BusinessDAO{

	@Override
	public Business create(Business stu) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int remove(Business stu) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int find(String username, String password) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Business> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	public List<Admin> findAll1() throws Exception {
		Connection con=null;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;	
	    List<Admin> student = new ArrayList<Admin>();
	    con=DbConnect.getDBconnection();
	    prepStmt = con.prepareStatement("select * from admin");
        rs = prepStmt.executeQuery();
        while(rs.next()) {
        	Admin stu2 = new Admin();
            stu2.setAdmin(rs.getString(1));              
            stu2.setPassword(rs.getString(2));
            student.add(stu2);
        }
        DbConnect.closeDB(con, prepStmt, rs);        
        return student;
	}

	@Override
	public void update(Business stu) throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	public int find_count() throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
//	    	 prepStmt = con.prepareStatement("select count(*) from businessuser");
//           rs = prepStmt.executeQuery();
	    	 Statement sta=con.createStatement();
	         rs  =sta.executeQuery("select * from admin");  
	         while(rs.next()){
	        	 result++;
	        	 }
	         
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}
	
	public int find_count_admin_mon() throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
//	    	 prepStmt = con.prepareStatement("select count(*) from businessuser");
//           rs = prepStmt.executeQuery();
	    	 Statement sta=con.createStatement();
	         rs  =sta.executeQuery("select * from admin where register_date like '%Mon%'");  
	         while(rs.next()){
	        	 result++;
	        	 }
	         
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}

	public int find_count_admin_tue() throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
//	    	 prepStmt = con.prepareStatement("select count(*) from businessuser");
//           rs = prepStmt.executeQuery();
	    	 Statement sta=con.createStatement();
	         rs  =sta.executeQuery("select * from admin where register_date like '%Tue%'");  
	         while(rs.next()){
	        	 result++;
	        	 }
	         
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}
	
	public int find_count_admin_wed() throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
//	    	 prepStmt = con.prepareStatement("select count(*) from businessuser");
//           rs = prepStmt.executeQuery();
	    	 Statement sta=con.createStatement();
	         rs  =sta.executeQuery("select * from admin where register_date like '%Wed%'");  
	         while(rs.next()){
	        	 result++;
	        	 }
	         
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}
	
	public int find_count_admin_thu() throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
//	    	 prepStmt = con.prepareStatement("select count(*) from businessuser");
//           rs = prepStmt.executeQuery();
	    	 Statement sta=con.createStatement();
	         rs  =sta.executeQuery("select * from admin where register_date like '%Thu%'");  
	         while(rs.next()){
	        	 result++;
	        	 }
	         
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}
	
	public int find_count_admin_fri() throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
//	    	 prepStmt = con.prepareStatement("select count(*) from businessuser");
//           rs = prepStmt.executeQuery();
	    	 Statement sta=con.createStatement();
	         rs  =sta.executeQuery("select * from admin where register_date like '%Fri%'");  
	         while(rs.next()){
	        	 result++;
	        	 }
	         
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}
	
	public int find_count_admin_sat() throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
//	    	 prepStmt = con.prepareStatement("select count(*) from businessuser");
//           rs = prepStmt.executeQuery();
	    	 Statement sta=con.createStatement();
	         rs  =sta.executeQuery("select * from admin where register_date like '%Sat%'");  
	         while(rs.next()){
	        	 result++;
	        	 }
	         
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}
	
	public int find_count_admin_sun() throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
//	    	 prepStmt = con.prepareStatement("select count(*) from businessuser");
//           rs = prepStmt.executeQuery();
	    	 Statement sta=con.createStatement();
	         rs  =sta.executeQuery("select * from admin where register_date like '%Sun%'");  
	         while(rs.next()){
	        	 result++;
	        	 }
	         
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}
	
	public int find_count_ordianry_mon() throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
//	    	 prepStmt = con.prepareStatement("select count(*) from businessuser");
//           rs = prepStmt.executeQuery();
	    	 Statement sta=con.createStatement();
	         rs  =sta.executeQuery("select * from ordinaryuser where register_date like '%Mon%'");  
	         while(rs.next()){
	        	 result++;
	        	 }
	         
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}

	public int find_count_ordianry_tue() throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
//	    	 prepStmt = con.prepareStatement("select count(*) from businessuser");
//           rs = prepStmt.executeQuery();
	    	 Statement sta=con.createStatement();
	         rs  =sta.executeQuery("select * from ordinaryuser where register_date like '%Tue%'");  
	         while(rs.next()){
	        	 result++;
	        	 }
	         
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}
	
	public int find_count_ordianry_wed() throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
//	    	 prepStmt = con.prepareStatement("select count(*) from businessuser");
//           rs = prepStmt.executeQuery();
	    	 Statement sta=con.createStatement();
	         rs  =sta.executeQuery("select * from ordinaryuser where register_date like '%Wed%'");  
	         while(rs.next()){
	        	 result++;
	        	 }
	         
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}
	
	public int find_count_ordianry_thu() throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
//	    	 prepStmt = con.prepareStatement("select count(*) from businessuser");
//           rs = prepStmt.executeQuery();
	    	 Statement sta=con.createStatement();
	         rs  =sta.executeQuery("select * from ordinaryuser where register_date like '%Thu%'");  
	         while(rs.next()){
	        	 result++;
	        	 }
	         
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}
	
	public int find_count_ordianry_fri() throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
//	    	 prepStmt = con.prepareStatement("select count(*) from businessuser");
//           rs = prepStmt.executeQuery();
	    	 Statement sta=con.createStatement();
	         rs  =sta.executeQuery("select * from ordinaryuser where register_date like '%Fri%'");  
	         while(rs.next()){
	        	 result++;
	        	 }
	         
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}
	
	public int find_count_ordianry_sat() throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
//	    	 prepStmt = con.prepareStatement("select count(*) from businessuser");
//           rs = prepStmt.executeQuery();
	    	 Statement sta=con.createStatement();
	         rs  =sta.executeQuery("select * from ordinaryuser where register_date like '%Sat%'");  
	         while(rs.next()){
	        	 result++;
	        	 }
	         
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}
	
	public int find_count_ordianry_sun() throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
//	    	 prepStmt = con.prepareStatement("select count(*) from businessuser");
//           rs = prepStmt.executeQuery();
	    	 Statement sta=con.createStatement();
	         rs  =sta.executeQuery("select * from ordinaryuser where register_date like '%Sun%'");  
	         while(rs.next()){
	        	 result++;
	        	 }
	         
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}
	
	public int find_count_business_mon() throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
//	    	 prepStmt = con.prepareStatement("select count(*) from businessuser");
//           rs = prepStmt.executeQuery();
	    	 Statement sta=con.createStatement();
	         rs  =sta.executeQuery("select * from businessuser where register_date like '%Mon%'");  
	         while(rs.next()){
	        	 result++;
	        	 }
	         
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}

	public int find_count_business_tue() throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
//	    	 prepStmt = con.prepareStatement("select count(*) from businessuser");
//           rs = prepStmt.executeQuery();
	    	 Statement sta=con.createStatement();
	         rs  =sta.executeQuery("select * from businessuser where register_date like '%Tue%'");  
	         while(rs.next()){
	        	 result++;
	        	 }
	         
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}
	
	public int find_count_business_wed() throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
//	    	 prepStmt = con.prepareStatement("select count(*) from businessuser");
//           rs = prepStmt.executeQuery();
	    	 Statement sta=con.createStatement();
	         rs  =sta.executeQuery("select * from businessuser where register_date like '%Wed%'");  
	         while(rs.next()){
	        	 result++;
	        	 }
	         
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}
	
	public int find_count_business_thu() throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
//	    	 prepStmt = con.prepareStatement("select count(*) from businessuser");
//           rs = prepStmt.executeQuery();
	    	 Statement sta=con.createStatement();
	         rs  =sta.executeQuery("select * from businessuser where register_date like '%Thu%'");  
	         while(rs.next()){
	        	 result++;
	        	 }
	         
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}
	
	public int find_count_business_fri() throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
//	    	 prepStmt = con.prepareStatement("select count(*) from businessuser");
//           rs = prepStmt.executeQuery();
	    	 Statement sta=con.createStatement();
	         rs  =sta.executeQuery("select * from businessuser where register_date like '%Fri%'");  
	         while(rs.next()){
	        	 result++;
	        	 }
	         
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}
	
	public int find_count_business_sat() throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
//	    	 prepStmt = con.prepareStatement("select count(*) from businessuser");
//           rs = prepStmt.executeQuery();
	    	 Statement sta=con.createStatement();
	         rs  =sta.executeQuery("select * from businessuser where register_date like '%Sat%'");  
	         while(rs.next()){
	        	 result++;
	        	 }
	         
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}
	
	public int find_count_business_sun() throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
//	    	 prepStmt = con.prepareStatement("select count(*) from businessuser");
//           rs = prepStmt.executeQuery();
	    	 Statement sta=con.createStatement();
	         rs  =sta.executeQuery("select * from businessuser where register_date like '%Sun%'");  
	         while(rs.next()){
	        	 result++;
	        	 }
	         
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}
	
}
