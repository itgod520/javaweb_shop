package com.dao;

import java.util.List;

import com.domain.Business;

public interface BusinessDAO {
	public abstract Business create(Business stu) throws Exception;
	public abstract int remove(Business stu) throws Exception;
	public abstract int find(String username,String password) throws Exception;
	public abstract List<Business> findAll() throws Exception;
	public abstract void update(Business stu) throws Exception;

}
