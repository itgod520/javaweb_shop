package com.dao;

import java.util.List;

import com.domain.Trade_record;


public interface TradeDAO {
	public abstract Trade_record create(Trade_record stu) throws Exception;
	public abstract int remove(Trade_record stu) throws Exception;
	public abstract int find(String username,String password) throws Exception;
	public abstract List<Trade_record> findAll() throws Exception;
	public abstract void update(Trade_record stu) throws Exception;
}
