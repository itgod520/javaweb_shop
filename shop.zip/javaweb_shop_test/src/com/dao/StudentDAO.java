package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.db.DbConnect;
import com.domain.Business;
import com.domain.Student;


public class StudentDAO implements IStudentDAO {
	protected static final String  FIELDS_INSERT ="ordinaryUser,password,register_date,sex";
	protected static String INSERT_SQL="insert into ordinaryuser ("+FIELDS_INSERT+")"+"values (?,?,?,?)";
	protected static String SELECT_SQL="select * from  ordinaryUser where ordinaryUser=?";
	protected static String UPDATE_SQL="update ordinaryUser set password=? where ordinaryUser=?";
	protected static String DELETE_SQL ="delete from ordinaryUser where ordinaryUser=?";
	public Student create(Student stu) throws Exception{
		  Connection con=null;
	      PreparedStatement prepStmt=null;
	      ResultSet rs=null;		
	      try{
	    	  con=DbConnect.getDBconnection();
	    	  prepStmt =con.prepareStatement(INSERT_SQL);	    	  
	    	  prepStmt.setString(1,stu.getOrdinaryUser());
	    	  prepStmt.setString(2,stu.getPassword());
	    	  prepStmt.setString(3,stu.getRegister_date());
	    	  prepStmt.setString(4,stu.getSex());
	          prepStmt.executeUpdate();
	      } catch(Exception e){
	       //
	      } finally{
	    	  DbConnect.closeDB(con, prepStmt, rs);
	      }
	     return stu;		
	}
	public int find(String username,String password) throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
	    	 prepStmt = con.prepareStatement(SELECT_SQL);
            prepStmt.setString(1,username);
            rs = prepStmt.executeQuery();
            if (rs.next()){
               String a=rs.getString(1);                  
               String b=rs.getString(2);
               if(a.equals(username)&&b.equals(password)){
            	   result=1;
               }
               else{
            	   result=-1;
               }
           }
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}
	
	public int find_count() throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
	    	 Statement sta=con.createStatement();
	         rs  =sta.executeQuery("select * from ordinaryuser");  
	         while(rs.next()){
	        	 result++;
	        	 }       
           System.out.println(result);
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}
	
	public List<Student> findAll() throws Exception {
		Connection con=null;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;	
	    List<Student> student = new ArrayList<Student>();
	    con=DbConnect.getDBconnection();
	    prepStmt = con.prepareStatement("select * from ordinaryUser");
        rs = prepStmt.executeQuery();
        while(rs.next()) {
        	Student stu2 = new Student();
            stu2.setOrdinaryUser(rs.getString(1));                 
            stu2.setPassword(rs.getString(2));
            student.add(stu2);
        }
        DbConnect.closeDB(con, prepStmt, rs);        
        return student;
	}
	public int remove(Student stu) throws Exception {
		Connection con=null;
		int flag=1;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    try {
	    	con=DbConnect.getDBconnection();
	    	prepStmt = con.prepareStatement(DELETE_SQL);
	        prepStmt.setString(1,stu.getOrdinaryUser());
	         flag=prepStmt.executeUpdate();
	        
	    }catch(Exception e) {
	          //
	    } finally{
	    	 DbConnect.closeDB(con, prepStmt, rs);
	    }
	    return flag;
	}
	
	public void update(Student stu) throws Exception {
		Connection con=null;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    try {
	    	con=DbConnect.getDBconnection();
            prepStmt = con.prepareStatement(UPDATE_SQL);
            prepStmt.setString(1,stu.getPassword());
	    	prepStmt.setString(2,stu.getOrdinaryUser());
	    	
	    	int rowCount=prepStmt.executeUpdate();
            if (rowCount == 0) {
                   throw new Exception("Update Error:Student Id:" + stu.getOrdinaryUser());
            }
        } catch (Exception e) {
                // handle exception
        } finally {
        	 DbConnect.closeDB(con, prepStmt, rs);
        }
    }
	public List<Student> findpart(String user,String pwd ) throws Exception {
		Connection con=null;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;	
	    List<Student> student = new ArrayList<Student>();
	    con=DbConnect.getDBconnection();
	    prepStmt = con.prepareStatement("select ordinaryUser,password from ordinaryuser where ordinaryUser=?");
	    prepStmt.setString(1,user);
        rs = prepStmt.executeQuery();
//        for(int i=0;i<10;i++){
//        	System.out.println(rs.getRow());
//        }            
        while(rs.next()) {
        	Student stu2 = new Student();
            stu2.setOrdinaryUser(rs.getString(1));                
            stu2.setPassword(rs.getString(2));
            student.add(stu2);
        }
        
        DbConnect.closeDB(con, prepStmt, rs);        
        return student;
	}
	
	
	
	public static void main(String[] args) throws Exception {
		
	StudentDAO student=new StudentDAO();
	student.find_count();
	
	}
}


