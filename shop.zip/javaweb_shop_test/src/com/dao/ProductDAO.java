package com.dao;

import java.util.List;

import com.domain.Business;
import com.domain.Product_info;

public interface ProductDAO {
	public abstract Product_info create(Product_info stu) throws Exception;
	public abstract int remove(Product_info stu) throws Exception;
	public abstract int find(String username,String password) throws Exception;
	public abstract List<Product_info> findAll() throws Exception;
	public abstract void update(Product_info stu) throws Exception;
}
