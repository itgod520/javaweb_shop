package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.db.DbConnect;
import com.domain.Product_info;

public class UserDao_product {
	public int getPageCount(int pageSize) throws Exception{
		
		 Connection conn = null;
		 PreparedStatement ps = null;
		 ResultSet rs = null;
		int recordCount=0,t1=0,t2=0;
		try {
				conn = DbConnect.getDBconnection();
				String sql = "select count(*) from shop_produce";
				ps=conn.prepareStatement(sql);
				rs=ps.executeQuery();
				 rs.next();
				 recordCount=rs.getInt(1);
				 t1=recordCount%pageSize;
				 t2=recordCount/pageSize;
				
			}finally {
				DbConnect.closeDB(conn, ps, rs);
			}
			 return t1==0?t2:t2+1;
	}
	
	public int getPageCountlist(int pageSize) throws Exception{
		
		 Connection conn = null;
		 PreparedStatement ps = null;
		 ResultSet rs = null;
		int recordCount=0,t1=0,t2=0;
		try {
				conn = DbConnect.getDBconnection();
				String sql = "select count(*) from product";
				ps=conn.prepareStatement(sql);
				rs=ps.executeQuery();
				 rs.next();
				 recordCount=rs.getInt(1);
				 t1=recordCount%pageSize;
				 t2=recordCount/pageSize;
				
			}finally {
				DbConnect.closeDB(conn, ps, rs);
			}
			 return t1==0?t2:t2+1;
	}
	
	public ArrayList<Product_info> findAllUser(int pageNo,int pageSize) throws Exception{
		
		
		 Connection conn = null;
		 PreparedStatement ps = null;
		 ResultSet rs = null;
		 int startRecno=(pageNo-1)*pageSize;
		 ArrayList<Product_info> userList=new ArrayList<Product_info>();
		try {
				conn = DbConnect.getDBconnection();
				String sql = "select * from shop_produce order by produce_id limit ?,?";
				ps=conn.prepareStatement(sql);
				 ps.setInt(1,startRecno);
				 ps.setInt(2,pageSize);
				rs=ps.executeQuery();
				 while(rs.next()){
					 
					 Product_info product=new Product_info();
					 product.setProduct_id(rs.getString(1));
					 product.setShop_id(rs.getString(2));
					 product.setProduce_name(rs.getString(3));
					 product.setPrice(rs.getDouble(4));
					 userList.add(product);
				 }
				
			}finally {
				DbConnect.closeDB(conn, ps, rs);;
			}
			 return userList;
	}
	public ArrayList<Product_info> findAllUser_list(int pageNo,int pageSize) throws Exception{
		
		
		 Connection conn = null;
		 PreparedStatement ps = null;
		 ResultSet rs = null;
		 int startRecno=(pageNo-1)*pageSize;
		 ArrayList<Product_info> userList=new ArrayList<Product_info>();
		try {
				conn = DbConnect.getDBconnection();
				String sql = "select * from product order by produce_id limit ?,?";
				ps=conn.prepareStatement(sql);
				 ps.setInt(1,startRecno);
				 ps.setInt(2,pageSize);
				rs=ps.executeQuery();
				 while(rs.next()){
					 
					 Product_info product=new Product_info();
					 product.setProduct_id(rs.getString(1));
					 product.setShop_id(rs.getString(2));
					 product.setProduce_name(rs.getString(3));
					 product.setPrice(rs.getDouble(4));
					 product.setProduce_lei(rs.getString(5));
					 userList.add(product);
				 }
				
			}finally {
				DbConnect.closeDB(conn, ps, rs);;
			}
			 return userList;
	}

	public static void main(String[] args) {
		UserDao ud=new UserDao();
		try {
			ud.findAllUser(1,5);
			System.out.println(ud.findAllUser(1,4).size());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
