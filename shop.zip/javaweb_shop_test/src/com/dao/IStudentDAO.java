package com.dao;

import java.util.List;
import com.domain.Student;

public interface IStudentDAO {
	public abstract Student create(Student stu) throws Exception;
	public abstract int remove(Student stu) throws Exception;
	public abstract int find(String username,String password) throws Exception;
	public abstract List<Student> findAll() throws Exception;
	public abstract void update(Student stu) throws Exception;
}
