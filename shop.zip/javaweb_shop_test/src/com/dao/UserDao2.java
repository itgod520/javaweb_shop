package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.db.DbConnect;

import com.domain.Student;

public class UserDao2 {
	public int getPageCount(int pageSize) throws Exception{
		
		 Connection conn = null;
		 PreparedStatement ps = null;
		 ResultSet rs = null;
		int recordCount=0,t1=0,t2=0;
		try {
				conn = DbConnect.getDBconnection();
				String sql = "select count(*) from ordinaryuser";
				ps=conn.prepareStatement(sql);
				rs=ps.executeQuery();
				 rs.next();
				 recordCount=rs.getInt(1);
				 t1=recordCount%pageSize;
				 t2=recordCount/pageSize;
				
			}finally {
				DbConnect.closeDB(conn, ps, rs);
			}
			 return t1==0?t2:t2+1;
	}
	public ArrayList<Student> findAllUser(int pageNo,int pageSize) throws Exception{
		
		
		 Connection conn = null;
		 PreparedStatement ps = null;
		 ResultSet rs = null;
		 int startRecno=(pageNo-1)*pageSize;
		 ArrayList<Student> userList=new ArrayList<Student>();
		try {
				conn = DbConnect.getDBconnection();
				String sql = "select * from ordinaryuser order by ordinaryUser limit ?,?";
				ps=conn.prepareStatement(sql);
				 ps.setInt(1,startRecno);
				 ps.setInt(2,pageSize);
				rs=ps.executeQuery();
				 while(rs.next()){
					 Student student=new Student();
					 student.setOrdinaryUser(rs.getString(1));
					 student.setPassword(rs.getString(2));
					 student.setRegister_date(rs.getString(3));
					 student.setSex(rs.getString(4));
					 userList.add(student);
				 }
				
			}finally {
				DbConnect.closeDB(conn, ps, rs);;
			}
			 return userList;
	}

	public static void main(String[] args) {
		UserDao ud=new UserDao();
		try {
			ud.findAllUser(1,5);
			System.out.println(ud.findAllUser(1,4).size());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
