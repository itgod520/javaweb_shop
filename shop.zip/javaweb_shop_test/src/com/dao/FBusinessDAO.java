package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.xml.registry.infomodel.User;

import com.db.DbConnect;
import com.domain.Business;
import com.domain.Student;



public class FBusinessDAO implements BusinessDAO{
	//protected static final String  FIELDS_INSERT ="businessUser,password,register_date,sex";
	protected static String INSERT_SQL="insert into businessuser (businessUser,password,register_date,sex)"+"values (?,?,?,?)";
	protected static String SELECT_SQL="select * from  businessuser where businessUser=?";
	protected static String UPDATE_SQL="update user set password=? where businessUser=?";
	protected static String DELETE_SQL ="delete from businessuser where businessUser=?";
	public Business create(Business bus) throws Exception{
		  Connection con=null;
	      PreparedStatement prepStmt=null;
	      ResultSet rs=null;		
	      try{
	    	  con=DbConnect.getDBconnection();  
	    	  prepStmt =con.prepareStatement(INSERT_SQL);	    	  
	    	  prepStmt.setString(1,bus.getBusinessUser());
	    	  prepStmt.setString(2,bus.getPassword());
	    	  prepStmt.setString(3,bus.getRegister_date());
	    	  prepStmt.setString(4,bus.getSex());
	          prepStmt.executeUpdate();

	      } finally{
	    	  DbConnect.closeDB(con, prepStmt, rs);
	      }
	     return bus;		
	}
	
	
	
	public int find(String businessUser,String password) throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
	    	 prepStmt = con.prepareStatement(SELECT_SQL);
            prepStmt.setString(1,businessUser);
            rs = prepStmt.executeQuery();
            if (rs.next()){
               String a=rs.getString(1);                  
               String b=rs.getString(2);
               if(a.equals(businessUser)&&b.equals(password)){
            	   result=1;
               }
               else{
            	   result=-1;
               }
           }
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}
	
	public int find_count() throws Exception {
		Connection con=null;
		int result=0;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 =new Student();
	    try {
	    	 con=DbConnect.getDBconnection();
//	    	 prepStmt = con.prepareStatement("select count(*) from businessuser");
//           rs = prepStmt.executeQuery();
	    	 Statement sta=con.createStatement();
	         rs  =sta.executeQuery("select * from businessuser");  
	         while(rs.next()){
	        	 result++;
	        	 }
	         
      } catch (Exception e) {
          // handle exception
      } 
      finally {
    	  DbConnect.closeDB(con, prepStmt, rs);
       }
		return result;
	}
	
	public List<Business> findAll() throws Exception {
		Connection con=null;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;	
	    List<Business> business = new ArrayList<Business>();
	    con=DbConnect.getDBconnection();
	    prepStmt = con.prepareStatement("select * from businessUser");
        rs = prepStmt.executeQuery();
        while(rs.next()) {
        	Business stu2 = new Business();
            stu2.setBusinessUser(rs.getString(1));                   
            stu2.setPassword(rs.getString(2));
            business.add(stu2);
        }
        DbConnect.closeDB(con, prepStmt, rs);        
        return business;
	}
	public int remove(Student stu) throws Exception {
		Connection con=null;
		int flag=1;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    try {
	    	con=DbConnect.getDBconnection();
	    	prepStmt = con.prepareStatement(DELETE_SQL);
	        prepStmt.setString(1,stu.getOrdinaryUser());
	         flag=prepStmt.executeUpdate();
	        
	    }catch(Exception e) {
	          //
	    } finally{
	    	 DbConnect.closeDB(con, prepStmt, rs);
	    }
	    return flag;
	}
	
	public void update(Student stu) throws Exception {
		Connection con=null;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    try {
	    	con=DbConnect.getDBconnection();
            prepStmt = con.prepareStatement(UPDATE_SQL);
            prepStmt.setString(1,stu.getPassword());
	    	prepStmt.setString(2,stu.getOrdinaryUser());
	    	
	    	int rowCount=prepStmt.executeUpdate();
            if (rowCount == 0) {
                   throw new Exception("Update Error:Student Id:" + stu.getOrdinaryUser());
            }
        } catch (Exception e) {
                // handle exception
        } finally {
        	 DbConnect.closeDB(con, prepStmt, rs);
        }
    }
	public List<Business> findpart(String user,String pwd ) throws Exception {
		Connection con=null;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;	
	    List<Business> student = new ArrayList<Business>();
	    con=DbConnect.getDBconnection();
	    prepStmt = con.prepareStatement("select * from businessUser where businessUser=?");
	    prepStmt.setString(1,user);
        rs = prepStmt.executeQuery();     
        while(rs.next()) {
        	Business stu2 = new Business();
            stu2.setBusinessUser(rs.getString(1));                   
            stu2.setPassword(rs.getString(2));  
            stu2.setRegister_date(rs.getString(3));
            stu2.setSex(rs.getString(4));
            student.add(stu2);
        }
        
        DbConnect.closeDB(con, prepStmt, rs);        
        return student;
	}
	
	public List<Business> findpart_admin(String user,String pwd ) throws Exception {
		Connection con=null;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;	
	    List<Business> student = new ArrayList<Business>();
	    con=DbConnect.getDBconnection();
	    prepStmt = con.prepareStatement("select * from admin where admin=?");
	    prepStmt.setString(1,user);
        rs = prepStmt.executeQuery();     
        while(rs.next()) {
        	Business stu2 = new Business();
            stu2.setBusinessUser(rs.getString(1));                   
            stu2.setPassword(rs.getString(2));  
            stu2.setRegister_date(rs.getString(3));
            stu2.setSex(rs.getString(4));
            student.add(stu2);
        }
        
        DbConnect.closeDB(con, prepStmt, rs);        
        return student;
	}
	
	
	
	@Override
	public int remove(Business stu) throws Exception {
		Connection con=null;
		int flag=1;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    try {
	    	con=DbConnect.getDBconnection();
	    	prepStmt = con.prepareStatement(DELETE_SQL);
	        prepStmt.setString(1,stu.getBusinessUser());
	         flag=prepStmt.executeUpdate();
	        
	    }catch(Exception e) {
	          //
	    } finally{
	    	 DbConnect.closeDB(con, prepStmt, rs);
	    }
	    return flag;
	}
	@Override
	public void update(Business stu) throws Exception {
		Connection con=null;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    try {
	    	con=DbConnect.getDBconnection();
            prepStmt = con.prepareStatement(UPDATE_SQL);
            prepStmt.setString(1,stu.getPassword());
	    	prepStmt.setString(2,stu.getBusinessUser());
	    	
	    	int rowCount=prepStmt.executeUpdate();
            if (rowCount == 0) {
                   throw new Exception("Update Error:Student Id:" + stu.getBusinessUser());
            }
        } catch (Exception e) {
                // handle exception
        } finally {
        	 DbConnect.closeDB(con, prepStmt, rs);
        }
		
	}
	
	

	public static void main(String[] args) throws Exception {
		
		FBusinessDAO bus=new FBusinessDAO();
		bus.find_count();
	
	}
	
}
