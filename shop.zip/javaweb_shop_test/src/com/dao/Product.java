package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.db.DbConnect;
import com.domain.Business;
import com.domain.Product_info;
import com.domain.Student;
public class Product implements ProductDAO{

	//protected static final String  FIELDS_INSERT ="businessUser,password,register_date,sex";
		protected static String INSERT_SQL="insert into shop_produce (produce_id,shop_id,produce_name,price,ordianryUser,pay_method,order_id,status)"+"values (?,?,?,?,?,?,?,?)";
		protected static String SELECT_SQL="select * from  shop_produce where businessUser=?";
		protected static String UPDATE_SQL="update shop_produce set password=? where businessUser=?";
		protected static String DELETE_SQL ="delete from shop_producer where businessUser=?";
		


		public int find(String businessUser,String password) throws Exception {
			Connection con=null;
			int result=0;
		    PreparedStatement prepStmt=null;
		    ResultSet rs=null;
		    Student stu2 =new Student();
		    try {
		    	 con=DbConnect.getDBconnection();
		    	 prepStmt = con.prepareStatement(SELECT_SQL);
	            prepStmt.setString(1,businessUser);
	            rs = prepStmt.executeQuery();
	            if (rs.next()){
	               String a=rs.getString(1);                  
	               String b=rs.getString(2);
	               if(a.equals(businessUser)&&b.equals(password)){
	            	   result=1;
	               }
	               else{
	            	   result=-1;
	               }
	           }
	      } catch (Exception e) {
	          // handle exception
	      } 
	      finally {
	    	  DbConnect.closeDB(con, prepStmt, rs);
	       }
			return result;
		}
		public List<Product_info> findAll() throws Exception {
			Connection con=null;
		    PreparedStatement prepStmt=null;
		    ResultSet rs=null;	
		    List<Product_info> product = new ArrayList<Product_info>();
		    con=DbConnect.getDBconnection();
		    prepStmt = con.prepareStatement("select * from shop_produce");
	        rs = prepStmt.executeQuery();
	        while(rs.next()) {
	        	Product_info pro = new Product_info();
	            pro.setProduct_id(rs.getString(1));
	            pro.setShop_id(rs.getString(2));
	            pro.setProduce_name(rs.getString(3));
	            pro.setPrice(rs.getDouble(4));
	            pro.setOrdianryUser(rs.getString(5));
	            pro.setPay_method(rs.getString(6));
	            product.add(pro);
	        }
	        DbConnect.closeDB(con, prepStmt, rs);        
	        return product;
		}
		
		public List<Product_info> findAllOrder(String userid) throws Exception {
			Connection con=null;
		    PreparedStatement prepStmt=null;
		    ResultSet rs=null;	
		    List<Product_info> product = new ArrayList<Product_info>();
		    con=DbConnect.getDBconnection();
		    prepStmt = con.prepareStatement("select * from shop_produce where ordianryUser=?");
		    prepStmt.setString(1,userid);
	        rs = prepStmt.executeQuery();
	        while(rs.next()) {
	        	Product_info pro = new Product_info();
	            pro.setProduct_id(rs.getString(1));
	            pro.setShop_id(rs.getString(2));
	            pro.setProduce_name(rs.getString(3));
	            pro.setPrice(rs.getDouble(4));
	            pro.setOrdianryUser(rs.getString(5));
	            pro.setPay_method(rs.getString(6));
	            pro.setOrder_id(rs.getString(7));
	            pro.setStatus(rs.getString(8));
	            product.add(pro);
	        }
	        DbConnect.closeDB(con, prepStmt, rs);        
	        return product;
		}
		
		public int remove1(Product_info stu) throws Exception {
			Connection con=null;
			int flag=1;
		    PreparedStatement prepStmt=null;
		    ResultSet rs=null;
		    try {
		    	con=DbConnect.getDBconnection();
		    	prepStmt = con.prepareStatement(DELETE_SQL);
		        prepStmt.setString(1,stu.getProduct_id());
		         flag=prepStmt.executeUpdate();
		        
		    }catch(Exception e) {
		          //
		    } finally{
		    	 DbConnect.closeDB(con, prepStmt, rs);
		    }
		    return flag;
		}
		
		public void update(Student stu) throws Exception {
			Connection con=null;
		    PreparedStatement prepStmt=null;
		    ResultSet rs=null;
		    try {
		    	con=DbConnect.getDBconnection();
	            prepStmt = con.prepareStatement(UPDATE_SQL);
	            prepStmt.setString(1,stu.getPassword());
		    	prepStmt.setString(2,stu.getOrdinaryUser());
		    	
		    	int rowCount=prepStmt.executeUpdate();
	            if (rowCount == 0) {
	                   throw new Exception("Update Error:Student Id:" + stu.getOrdinaryUser());
	            }
	        } catch (Exception e) {
	                // handle exception
	        } finally {
	        	 DbConnect.closeDB(con, prepStmt, rs);
	        }
	    }
		public List<Business> findpart(String user,String pwd ) throws Exception {
			Connection con=null;
		    PreparedStatement prepStmt=null;
		    ResultSet rs=null;	
		    List<Business> student = new ArrayList<Business>();
		    con=DbConnect.getDBconnection();
		    prepStmt = con.prepareStatement("select * from shop_product where produce_id=?");
		    prepStmt.setString(1,user);
	        rs = prepStmt.executeQuery();
//	        for(int i=0;i<10;i++){
//	        	System.out.println(rs.getRow());
//	        }
	        
	       
	        while(rs.next()) {
	        	Business stu2 = new Business();
	            stu2.setBusinessUser(rs.getString(1));                   
	            stu2.setPassword(rs.getString(2));
	            student.add(stu2);
	        }
	        if(rs.getRow()==0){
	        	Business s=new Business();
	        	s.setBusinessUser("*&^%$#@!");
	        	s.setPassword("!@#$%^&*");
	        	student.add(s);
	        	System.out.println("�ҿ����ж���");
	        }
	        DbConnect.closeDB(con, prepStmt, rs);        
	        return student;
		}
		
				
		public int remove(Business stu) throws Exception {
			Connection con=null;
			int flag=1;
		    PreparedStatement prepStmt=null;
		    ResultSet rs=null;
		    try {
		    	con=DbConnect.getDBconnection();
		    	prepStmt = con.prepareStatement(DELETE_SQL);
		        prepStmt.setString(1,stu.getBusinessUser());
		         flag=prepStmt.executeUpdate();
		        
		    }catch(Exception e) {
		          //
		    } finally{
		    	 DbConnect.closeDB(con, prepStmt, rs);
		    }
		    return flag;
		}

		public void update(Business stu) throws Exception {
			Connection con=null;
		    PreparedStatement prepStmt=null;
		    ResultSet rs=null;
		    try {
		    	con=DbConnect.getDBconnection();
	            prepStmt = con.prepareStatement(UPDATE_SQL);
	            prepStmt.setString(1,stu.getPassword());
		    	prepStmt.setString(2,stu.getBusinessUser());
		    	
		    	int rowCount=prepStmt.executeUpdate();
	            if (rowCount == 0) {
	                   throw new Exception("Update Error:Student Id:" + stu.getBusinessUser());
	            }
	        } catch (Exception e) {
	                // handle exception
	        } finally {
	        	 DbConnect.closeDB(con, prepStmt, rs);
	        }
			
		}


		
		public com.domain.Product_info create(com.domain.Product_info pro) throws Exception {
			Connection con=null;
		      PreparedStatement prepStmt=null;
		      ResultSet rs=null;		
		      try{
		    	  con=DbConnect.getDBconnection();  
		    	  prepStmt =con.prepareStatement(INSERT_SQL);	    	  
		    	  prepStmt.setString(1,pro.getProduct_id());
		    	  prepStmt.setString(2,pro.getShop_id());	  
		    	  prepStmt.setString(3,pro.getProduce_name());
		    	  prepStmt.setDouble(4,pro.getPrice());
		    	  prepStmt.setString(5, pro.getOrdianryUser());
		    	  prepStmt.setString(6, pro.getPay_method());
		    	  prepStmt.setString(7, pro.getOrder_id());
		    	  prepStmt.setString(8, pro.getStatus());
		          prepStmt.executeUpdate();

		      } finally{
		    	  DbConnect.closeDB(con, prepStmt, rs);
		      }
		     return pro;		
		}

		public Product_info create1(Product_info pro) throws Exception {
			Connection con=null;
		      PreparedStatement prepStmt=null;
		      ResultSet rs=null;		
		      try{
		    	  con=DbConnect.getDBconnection();  
		    	  prepStmt =con.prepareStatement("insert into product (produce_id,shop_id,produce_name,price,produce_lei)"+"values (?,?,?,?,?)");	    	  
		    	  prepStmt.setString(1,pro.getProduct_id());
		    	  prepStmt.setString(2,pro.getShop_id());	  
		    	  prepStmt.setString(3,pro.getProduce_name());
		    	  prepStmt.setDouble(4,pro.getPrice());
		    	  prepStmt.setString(5, pro.getProduce_lei());
		          prepStmt.executeUpdate();

		      } finally{
		    	  DbConnect.closeDB(con, prepStmt, rs);
		      }
		     return pro;		
		}







		
		public int remove11(Product_info pro) throws Exception {
			Connection con=null;
			int flag=1;
		    PreparedStatement prepStmt=null;
		    ResultSet rs=null;
		    try {
		    	con=DbConnect.getDBconnection();
		    	prepStmt = con.prepareStatement("delete from product where produce_id=?");
		        prepStmt.setString(1,pro.getProduct_id());
		         flag=prepStmt.executeUpdate();
		        
		    }catch(Exception e) {
		          //
		    } finally{
		    	 DbConnect.closeDB(con, prepStmt, rs);
		    }
		    return flag;
		}



		public void update(com.domain.Product_info stu) throws Exception {
			// TODO Auto-generated method stub
			
		}
		@Override
		public int remove(Product_info stu) throws Exception {
			// TODO Auto-generated method stub
			return 0;
		}
		
		
	
	
}
