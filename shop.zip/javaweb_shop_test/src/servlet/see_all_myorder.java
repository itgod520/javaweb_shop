package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.Product;
import com.dao.UserDao;
import com.domain.Product_info;

public class see_all_myorder extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		HttpSession session=request.getSession();
		String userid=session.getAttribute("userid").toString();
		
		
	    UserDao userDao = new UserDao();
	    Product pro=new Product();
	    try {
			List<Product_info> myorder = pro.findAllOrder(userid);
			request.setAttribute("order2",myorder);
		       RequestDispatcher rd = request.getRequestDispatcher("myorder.jsp");
		       rd.forward(request,response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
