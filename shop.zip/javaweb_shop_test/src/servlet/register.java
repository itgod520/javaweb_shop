 package servlet;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.FBusinessDAO;
import com.dao.StudentDAO;
import com.domain.Business;
import com.domain.Student;

public class register extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
		
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		   request.setCharacterEncoding("utf-8");
		   Date date=new Date(); 
		   String businessUser=request.getParameter("userid");
		   String password=request.getParameter("userpwd");
		   String sex=request.getParameter("list");
		   String radio_value=request.getParameter("user1");
		   String register_date= date.toString();
		   Business business=new Business();
		   business.setBusinessUser(businessUser);
		   business.setPassword(password);
		   business.setSex(sex);
		   business.setRegister_date(register_date);
		   FBusinessDAO fbusiness=new FBusinessDAO();
		   StudentDAO student=new StudentDAO(); 
		   Student stu=new Student();
		   stu.setOrdinaryUser(businessUser);
		   stu.setPassword(password);
		   stu.setRegister_date(register_date);
		   stu.setSex(sex);
		   try {//���������ж�
			   if(radio_value.equals("businessUser")){
				   fbusiness.create(business);//�̼�
					request.getRequestDispatcher("turn2_to_main.jsp").forward(request, response);
			   }
			   else if(radio_value.equals("ordinaryUser")){
				   student.create(stu);//�û�
				   request.getRequestDispatcher("turn2_to_main.jsp").forward(request, response);
			   }
//			fbusiness.create(business);
//			request.getRequestDispatcher("turn_to_main.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		   
	}

}
