package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.UserDao;
import com.domain.Business;

public class FindAllUserServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int pageNo = 1;int pageSize=5;
	    String strPageNo = request.getParameter("pageNo"); 
	    if(strPageNo != null)
	    {
	       pageNo = Integer.parseInt(strPageNo); // ���ַ���ת��������
	    }
	    UserDao userDao = new UserDao();

	    try{
	       List<Business> businessuser = userDao.findAllUser(pageNo,pageSize);
	       request.setAttribute("userlist",businessuser);
	       Integer pageCount = new Integer(userDao.getPageCount(pageSize));
	       request.setAttribute("pageCount",pageCount);
	       request.setAttribute("pageNo",pageNo);
	       RequestDispatcher rd = request.getRequestDispatcher("search_sale.jsp");
	       rd.forward(request,response);
	       
	    }catch(Exception e){
	      e.printStackTrace();
	    }
	    
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
