package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.Trade_dao;
import com.domain.Product_info;

public class updata_order extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String id=request.getParameter("id");
		Product_info pro_info=new Product_info();
		Trade_dao tdao=new Trade_dao();
		pro_info.setOrder_id(id);
		pro_info.setStatus("��");
		try {
			tdao.updateStatus(pro_info);
			request.getRequestDispatcher("manager_search_trade").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
