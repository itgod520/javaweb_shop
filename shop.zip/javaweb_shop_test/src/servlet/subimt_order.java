package servlet;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.Product;
import com.dao.Trade_dao;
import com.domain.Product_info;

public class subimt_order extends HttpServlet {
	//static int ordernum=0
	
   
	 public static boolean useLoop(String[] arr, String targetValue) {
			for(String s: arr){
			if(s.equals(targetValue))
			return true;
			}
			return false;
			}//����Ŀ��ֵ
			
	 
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
		
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		int flag;
		request.setCharacterEncoding("utf-8");
		
		String paylist=request.getParameter("paylist");//��ȡ֧����ʽ
		HttpSession session=request.getSession();
		String userid=session.getAttribute("userid").toString();
		Date order_date=new Date();
		Product_info shop1=new Product_info();
		Product_info shop2=new Product_info();
		Product_info shop3=new Product_info();
		Product_info shop4=new Product_info();
		Product_info shop5=new Product_info();
		Product_info shop6=new Product_info();
		Product_info shop7=new Product_info();
		
		//
		
		//
		
		//
		
		//
		
		//
		
		//
		
		//
		
		String allpro=request.getParameter("allpro");
		String []a=new String[allpro.length()];
		for(int i=0;i<allpro.length();i++){
			a[i]=allpro.substring(i,i+1);
		}
		Product pro_dao=new Product();
		Trade_dao t_dao=new Trade_dao();
		if(useLoop(a,"1")){
			try {
				shop1.setProduce_name("С��(MI)С��9 ");
				shop1.setProduct_id("1");
				shop1.setProduct_business("С��֮��");
				shop1.setOrder_num("1000100001");
				//shop1.setOrder_date(order_date.toLocaleString());
				shop1.setPrice(3299.00);
				
				shop1.setShop_id("1");
				shop1.setPay_method(paylist);
				shop1.setOrdianryUser(userid);
				shop1.setStatus("δ����");
				shop1.setOrder_id(new Date().toLocaleString());
			
				pro_dao.create(shop1);
				 
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		if(useLoop(a,"2")){
			try {
				shop2.setProduce_name("С��9 SE ");
				shop2.setProduct_id("2");
				shop2.setProduct_business("С��֮��");
				shop2.setOrder_num("1000100002");
				shop2.setOrder_date(order_date.toString());
				shop2.setPrice(1999.00);
				
				shop2.setShop_id("2");
				shop2.setPay_method(paylist);
				shop2.setOrder_id(new Date().toLocaleString());
				shop2.setOrdianryUser(userid);
				shop2.setStatus("δ����");
				pro_dao.create(shop2);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		if(useLoop(a,"3")){
			try {
				shop3.setProduce_name("С�� ����Redmi Note7Pro ");
				shop3.setProduct_id("3");
				shop3.setProduct_business("С��֮��");
				shop3.setOrder_num("1000100003");
				shop3.setOrder_date(order_date.toString());
				shop3.setPrice(1599.00);
				
				shop3.setShop_id("3");
				shop3.setPay_method(paylist);
				shop3.setOrder_id(new Date().toLocaleString());
				shop3.setOrdianryUser(userid);
				shop3.setStatus("δ����");
				pro_dao.create(shop3);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		if(useLoop(a,"4")){
			try {
				shop4.setProduce_name("С��8 �ഺ�� ");
				shop4.setProduct_id("4");
				shop4.setProduct_business("С��֮��");
				shop4.setOrder_num("1000100004");
				shop4.setOrder_date(order_date.toString());
				shop4.setPrice(1499.0);
				shop4.setShop_id("4");
				shop4.setPay_method(paylist);
				shop4.setOrder_id(new Date().toLocaleString());
				shop4.setOrdianryUser(userid);
				shop4.setStatus("δ����");
				pro_dao.create(shop4);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		if(useLoop(a,"5")){
			try {
				shop5.setProduce_name("ŵ���� NOKIA X6 ");
				shop5.setProduct_id("5");
				shop5.setProduct_business("ŵ����");
				shop5.setOrder_num("1000100005");
				shop5.setOrder_date(order_date.toString());
				shop5.setPrice(1499.00);
				
				shop5.setShop_id("5");
				shop5.setPay_method(paylist);
				shop5.setOrder_id(new Date().toLocaleString());
				shop5.setOrdianryUser(userid);
				shop5.setStatus("δ����");
				pro_dao.create(shop5);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		if(useLoop(a,"6")){
			try {
				shop6.setProduce_name("��ݮ��BlackBerry��KEY2����� ");
				shop6.setProduct_id("6");
				shop6.setProduct_business("��ݮ֮��");
				shop6.setOrder_num("1000100006");
				shop6.setOrder_date(order_date.toString());
				shop6.setPrice(3299.00);
				
				shop6.setShop_id("6");
				shop6.setPay_method(paylist);
				shop6.setOrder_id(new Date().toLocaleString());
				shop6.setOrdianryUser(userid);
				shop6.setStatus("δ����");
				pro_dao.create(shop6);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		if(useLoop(a,"7")){
			try {
				shop7.setProduce_name("Apple iPad miniƽ����� ");
				shop7.setProduct_id("7");
				shop7.setProduct_business("С��֮��");
				shop7.setOrder_num("1000100007");
				shop7.setOrder_date(order_date.toString());
				shop7.setPrice(3299.00);
				
				shop7.setShop_id("7");
				shop7.setPay_method(paylist);
				shop7.setOrder_id(new Date().toLocaleString());
				shop7.setOrdianryUser(userid);
				shop7.setStatus("δ����");
				pro_dao.create(shop7);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		request.getRequestDispatcher("turn3_to_main.jsp").forward(request,response);
	}
	
     

}
