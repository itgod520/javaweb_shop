package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.domain.Product_info;

public class shopping_chart_value extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		
		ArrayList<Product_info> list2= (ArrayList<Product_info>) session.getAttribute("list1");
//		for(int s=0;s<100;s++){
//			System.out.println(list.isEmpty());
//		}
//		boolean ss=list.isEmpty();
		if(list2.size()==0){
			request.getRequestDispatcher("shopping_chart.jsp").forward(request, response);
		}
		else{
			request.getRequestDispatcher("read.jsp").forward(request, response);
		}
		
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
