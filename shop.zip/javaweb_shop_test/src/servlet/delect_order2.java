package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.Trade_dao;
import com.domain.Product_info;

public class delect_order2 extends HttpServlet {
	/*
	 * delect_order2������manager_search_trade��ɾ��
	 * 
	 * */
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			 String id=request.getParameter("id");
			
			 Trade_dao tdao=new Trade_dao();
			 Product_info pro=new Product_info();
			 pro.setOrder_id(id);
			 try { 
				tdao.create_delect_order_record(pro);
				tdao.remove(pro);
				
				request.getRequestDispatcher("manager_search_trade").forward(request, response);;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
