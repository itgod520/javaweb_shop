package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.domain.Product_info;

public class turn_toget_info2 extends HttpServlet {
	public ArrayList<Product_info> list1=new ArrayList<Product_info>();
		
        public static boolean useLoop(String[] arr, String targetValue) {
		for(String s: arr){
		if(s.equals(targetValue))
		return true;
		}
		return false;
		}//����Ŀ��ֵ
		
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		int flag;
		Date order_date=new Date();
		Product_info shop1=new Product_info();
		Product_info shop2=new Product_info();
		Product_info shop3=new Product_info();
		Product_info shop4=new Product_info();
		Product_info shop5=new Product_info();
		Product_info shop6=new Product_info();
		Product_info shop7=new Product_info();
		shop1.setProduce_name("С��(MI)С��9 ");
		shop1.setProduct_id("1");
		shop1.setProduct_business("С��֮��");
		shop1.setOrder_num("1000100001");
		shop1.setOrder_date(order_date.toLocaleString());
		shop1.setPrice(3299.00);
		//
		shop2.setProduce_name("С��9 SE ");
		shop2.setProduct_id("2");
		shop2.setProduct_business("С��֮��");
		shop2.setOrder_num("1000100002");
		shop2.setOrder_date(order_date.toString());
		shop2.setPrice(1999.00);
		//
		shop3.setProduce_name("С�� ����Redmi Note7Pro ");
		shop3.setProduct_id("3");
		shop3.setProduct_business("С��֮��");
		shop3.setOrder_num("1000100003");
		shop3.setOrder_date(order_date.toString());
		shop3.setPrice(1599.00);
		//
		shop4.setProduce_name("С��8 �ഺ�� ");
		shop4.setProduct_id("4");
		shop4.setProduct_business("С��֮��");
		shop4.setOrder_num("1000100004");
		shop4.setOrder_date(order_date.toString());
		//
		shop5.setProduce_name("ŵ���� NOKIA X6 ");
		shop5.setProduct_id("5");
		shop5.setProduct_business("ŵ����");
		shop5.setOrder_num("1000100005");
		shop5.setOrder_date(order_date.toString());
		shop5.setPrice(1499.00);
		//
		shop6.setProduce_name("��ݮ��BlackBerry��KEY2����� ");
		shop6.setProduct_id("6");
		shop6.setProduct_business("��ݮ֮��");
		shop6.setOrder_num("1000100006");
		shop6.setOrder_date(order_date.toString());
		shop6.setPrice(3299.00);
		//
		shop7.setProduce_name("Apple iPad miniƽ����� ");
		shop7.setProduct_id("7");
		shop7.setProduct_business("С��֮��");
		shop7.setOrder_num("1000100007");
		shop7.setOrder_date(order_date.toString());
		shop7.setPrice(3299.00);
		//

		String[] checkbox_value=request.getParameterValues("shop");
		String a1="shop1",a2="shop2",a3="shop3",a4="shop4",a5="shop5",a6="shop6",a7="shop7";
		if(useLoop(checkbox_value,a1)){
			list1.add(shop1);
		}
		 if(useLoop(checkbox_value,a2)){
			 list1.add(shop2);
		}
		 if(useLoop(checkbox_value,a3)){
			 list1.add(shop3);
		}
		 if(useLoop(checkbox_value,a4)){
			 list1.add(shop4);
		}
		 if(useLoop(checkbox_value,a5)){
			 list1.add(shop5);
		}
		 if(useLoop(checkbox_value,a6)){
			 list1.add(shop6);
		 }
		 if(useLoop(checkbox_value,a7)){
			 list1.add(shop7);
		 }
		 
		 
		 HttpSession session = request.getSession();
		 session.setAttribute("list1",list1);

		 request.getRequestDispatcher("add_success.jsp").forward(request, response);
	}

}
