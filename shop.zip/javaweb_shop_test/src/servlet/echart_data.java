package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.AdminDAO;
import com.dao.FBusinessDAO;
import com.dao.StudentDAO;

public class echart_data extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        StudentDAO user=new StudentDAO();
        FBusinessDAO bus=new FBusinessDAO();
        AdminDAO admin=new AdminDAO();
        HttpSession session=request.getSession();
        HttpSession session1=request.getSession();
        HttpSession session2=request.getSession();
        //���ڴ��ע��ʱ��ĻỰ
        HttpSession session3=request.getSession();
        HttpSession session4=request.getSession();
        HttpSession session5=request.getSession();
        HttpSession session6=request.getSession();
        HttpSession session7=request.getSession();
        HttpSession session8=request.getSession();
        HttpSession session9=request.getSession();
        
        
        try {
			int business=bus.find_count();
			int usernum=user.find_count();
			int adminnum=admin.find_count();
			int mon=admin.find_count_admin_mon()+admin.find_count_business_mon()+admin.find_count_ordianry_mon();
			int tue=admin.find_count_admin_tue()+admin.find_count_business_tue()+admin.find_count_ordianry_tue();
			int wed=admin.find_count_admin_wed()+admin.find_count_business_wed()+admin.find_count_ordianry_wed();
			int thu=admin.find_count_admin_thu()+admin.find_count_business_thu()+admin.find_count_ordianry_thu();
			int fri=admin.find_count_admin_fri()+admin.find_count_business_fri()+admin.find_count_ordianry_fri();
			int sat=admin.find_count_admin_sat()+admin.find_count_business_sat()+admin.find_count_ordianry_sat();
			int sun=admin.find_count_admin_sun()+admin.find_count_business_sun()+admin.find_count_ordianry_sun();
			session.setAttribute("business_num", business);
			session1.setAttribute("usernum", usernum);
			session2.setAttribute("admin", adminnum);
			session3.setAttribute("mon", mon);
			session4.setAttribute("tue", tue);
			session5.setAttribute("wed", wed);
			session6.setAttribute("thu", thu);
			session7.setAttribute("fri", fri);
			session8.setAttribute("sat", sat);
			session9.setAttribute("sun", sun);
			request.getRequestDispatcher("echart_data.jsp").forward(request, response);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
		
	}

}
