package servlet;

import java.awt.List;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.domain.Product_info;

public class turn_toget_info extends HttpServlet {
	
	ArrayList<Product_info> list=new ArrayList<Product_info>();
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Date order_date=new Date();
		Product_info product1=new Product_info();
		product1.setProduce_name("С��(MI)С��9");
		product1.setProduct_id("0001");
		product1.setProduct_business("С��֮��");
		product1.setOrder_num("1000100001");
		product1.setOrder_date(order_date.toString());
		
		list.add(product1);//ok
		HttpSession session = request.getSession();
		session.setAttribute("list1",list);
		request.getRequestDispatcher("main_page.jsp").forward(request, response);
		
	}

	
		 
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request, response);
	}

}
