package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.Trade_dao;
import com.domain.Product_info;

public class delect_order extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			 String id=request.getParameter("id");
			
			 Trade_dao tdao=new Trade_dao();
			 Product_info pro=new Product_info();
			 pro.setOrder_id(id);
			 try {
				tdao.remove(pro);
				request.getRequestDispatcher("search_trade").forward(request, response);;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
