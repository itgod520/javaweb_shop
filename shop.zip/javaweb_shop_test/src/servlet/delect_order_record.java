package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.UserDao_trade_record;
import com.domain.Product_info;

public class delect_order_record extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int pageNo = 1;int pageSize=5;
	    String strPageNo = request.getParameter("pageNo"); 
	    if(strPageNo != null)
	    {
	       pageNo = Integer.parseInt(strPageNo); // ���ַ���ת��������
	    }
	   UserDao_trade_record userDao = new  UserDao_trade_record();

	    try{
	       List<Product_info> product = userDao.findAllUser_delect_order_record(pageNo,pageSize);
	       request.setAttribute("product2",product);
	       Integer pageCount = new Integer(userDao.getPageCount3(pageSize));
	       request.setAttribute("pageCount",pageCount);
	       request.setAttribute("pageNo",pageNo);
	       RequestDispatcher rd = request.getRequestDispatcher("delect_order_record.jsp");
	       rd.forward(request,response);
	       
	    }catch(Exception e){
	      e.printStackTrace();
	    }
	    
		
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
		
	}

}
