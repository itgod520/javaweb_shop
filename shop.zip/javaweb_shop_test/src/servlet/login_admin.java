package servlet;

import java.awt.List;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.AdminDAO;
import com.domain.Admin;

public class login_admin extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
		
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String userid = request.getParameter("userid");
		String userpwd = request.getParameter("userpwd");
		HttpSession session = request.getSession();
		HttpSession session1 = request.getSession();
		String info;
		session.setAttribute("userid", userid);
		AdminDAO admin=new AdminDAO();
		try {
			java.util.List<Admin> list=admin.findAll1();
			for(int i=0;i<list.size();i++){
				String a=list.get(i).getAdmin();
				String b=list.get(i).getPassword();
				if(a.equals(userid)&&b.equals(userpwd)){
					request.getRequestDispatcher("admin_control.jsp").forward(request, response);
				}
			}
			info="�û������������������û���������";
			session1.setAttribute("info", info);
			//request.getRequestDispatcher("login_admin.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
