package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.mail.Session;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.domain.Product_info;

public class delect_product extends HttpServlet {
     
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id=request.getParameter("id");
		 HttpSession session = request.getSession();
		 ArrayList<Product_info> list =(ArrayList<Product_info>)session.getAttribute("list1");
		String[] ss=request.getParameterValues("list2");
		for(int i=0;i<list.size();i++){
			System.out.println(list.get(i));
		}
		
		for(int i=0;i<list.size();i++){
			if(list.get(i).getProduct_id().equals(id)){
			list.remove(i);
			}
	}
		request.getRequestDispatcher("read.jsp").forward(request, response);
		
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doPost(request, response);
	}

}
