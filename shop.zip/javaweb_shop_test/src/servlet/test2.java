package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.FBusinessDAO;
import com.dao.StudentDAO;
import com.domain.Business;
import com.domain.Student;

public class test2 extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");

		Student stu=new Student();
		StudentDAO sdao=new StudentDAO();
		Business bus=new Business();
		FBusinessDAO busdao=new FBusinessDAO();
		String userid = request.getParameter("userid");
		String userpwd = request.getParameter("userpwd");
		String radio_value=request.getParameter("user");
		String usercheckcode = request.getParameter("checkcode");
		HttpSession session = request.getSession();
		HttpSession session1 = request.getSession();
		String servercheckcode = (String) session.getAttribute("checkCode");
		
		session1.setAttribute("userid",userid);
	    stu.setOrdinaryUser(userid);
		stu.setPassword(userpwd);
		
		String info="";
		try {
			if(radio_value.equals("ordinaryUser")){
				List<Student> list=sdao.findpart(userid,userpwd);
				for(int i=0;i<list.size();i++){
					String a=list.get(i).getOrdinaryUser();
					String b=list.get(i).getPassword();
					if(!servercheckcode.equalsIgnoreCase(usercheckcode)){
						info = "��֤�벻��ȷ������������";
						request.setAttribute("info", info);
						request.getRequestDispatcher("login_page.jsp").forward(request, response);
					}				
					else if(a.equals(userid)&&b.equals(userpwd)){
						request.getRequestDispatcher("turn_to_main.jsp").forward(request, response);
					}
					else {
						System.out.println("yyy");
						request.getRequestDispatcher("fail_page.jsp").forward(request, response);
					}
				   }
			}
			else{
				List<Business> list=busdao.findpart(userid,userpwd);
				for(int i=0;i<list.size();i++){
					String a=list.get(i).getBusinessUser();
					String b=list.get(i).getPassword();
					if(!servercheckcode.equalsIgnoreCase(usercheckcode)){
						info = "��֤�벻��ȷ������������";
						request.setAttribute("info", info);
						request.getRequestDispatcher("login_page.jsp").forward(request, response);
					}				
					else if(a.equals(userid)&&b.equals(userpwd)){
						request.getRequestDispatcher("saler_control.jsp").forward(request, response);
					}
					else{
						System.out.println("xxxx");
						request.getRequestDispatcher("fail_page.jsp").forward(request, response);
					}
				   }
			}
		

		} catch (Exception e) {
			for(int i=0;i<100;i++){
				System.out.println("find error");
				System.out.println(e.getMessage());
			}
			request.setAttribute("user",e.getMessage());
			e.printStackTrace();
		}
		
	}

}
