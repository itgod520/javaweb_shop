package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.Product;
import com.domain.Product_info;

public class add_product extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
		
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String produce_id=request.getParameter("produce_id");
		String shop_id= request.getParameter("shop_id");
		String produce_name= request.getParameter("produce_name");
		String price= request.getParameter("price");
		String value=request.getParameter("produce");
		Product_info pro=new Product_info();
		Product pdao=new Product();
		pro.setProduct_id(produce_id);
		pro.setShop_id(shop_id);
		pro.setProduce_name(produce_name);
		pro.setPrice(Integer.parseInt(price));
		pro.setProduce_lei(value);
		try {
			pdao.create1(pro);
			HttpSession session=request.getSession();
			String info="���ӳɹ�";
			session.setAttribute("success_add",info);
			request.getRequestDispatcher("add_product.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
