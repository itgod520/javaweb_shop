/**
 * 
 */
function changeimgcoce(){
	
	document.getElementById("check_img").src="checkcode?"+(new Date()).getTime();
	var checkcodetext=document.getElementById("checkcode").value;
	alert(checkcodetext);
	var checkcode_img=document.getElementById("check_img").src="checkcode?"+(new Date()).getTime().value;
	if(checkcodetext==checkcode_img){
		
	}
	else{
		document.getElementById("check_img").src="checkcode?"+(new Date()).getTime();
	}
}